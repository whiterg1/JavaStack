/**
 * 
 */
 
 alert("This is the time template");