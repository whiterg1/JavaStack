package com.codingdojo.dojosurvey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosurveyApplicationTests {

	@Test
	void contextLoads() {
	}

}
